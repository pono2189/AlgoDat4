import java.util.*;
import java.lang.Math; 
public class DivideConquer {
	private static ArrayList<Point> randArr(int size){ //parameter size is the length of the array
												// -> the number of random points you want to have 
		Random rand = new Random();
		ArrayList<Point> array = new ArrayList<Point>();
		
		for (int i = 0; i < size; i++){ //creates an array list the size of the parameter size
			Point p = new Point(rand.nextInt()%100,rand.nextInt()%100); //creates new point with random x&y values
			// to make it easier to check, I wanted only numbers < 100, so I used random numbers modulo 100
			array.add(p); //add point p to the array
		}
		return array;
	}
	
	private static float distance(Point p1, Point p2) 
	{ 
	    return (float)Math.abs((Math.sqrt(((p1.getX()-p2.getX())*(p1.getX()-p2.getX())) + ((p1.getY()-p2.getY())*(p1.getY()-p2.getY())))));
	} 
	
	private static float divCon(ArrayList<Point> array){
		ArrayList<Point> left = new ArrayList<Point>(); 
		ArrayList<Point> right = new ArrayList<Point>();
		float minR = Float.MAX_VALUE; 
		float minL = Float.MAX_VALUE;
		float min = Float.MAX_VALUE;
		sortX(array);
		
		if (array.size() <= 3){
			return naiveAlg(array);
		}
		
		
		for (int i = 0; i <= array.size()/2; i++){ //safes the first half of array in left
			left.add(array.get(i));
		}
		
		for (int i = (array.size()/2)+1; i < array.size(); i++){ //safes the second half of array in right
			right.add(array.get(i));
		}
		
		//sortX(left);
		//sortX(right);
		
		minL = divCon(left); //gets minimal distance on the left
		minR = divCon(right); //gets minimal distance on the right
		if (minL <= minR){  // compares minL and minR to get the ultimate minimum
			min = minL;
		}
		
		else{
			min = minR;
		}
		
		ArrayList<Point> midStrip = new ArrayList<Point>();
		int mid = array.size()/2; //start at the middle
		int j = (array.size()/2) - 1; //starts one before the middle
		
		while ((j >= 0) && (Math.abs(array.get(mid).getX() - array.get(j).getX()) <= min )){ //adds the points within range of min from i
			midStrip.add(array.get(j));
			j--;
		}
		
		j = (array.size()/2) + 1; //starts one after the middle
		
		while ((array.size() > j)&&(Math.abs(array.get(mid).getX()- array.get(j).getX()) <= min) ){
			midStrip.add(array.get(j)); //adds all of the points from the middle strip that are within the min distance to i
			j++;
		}
		midStrip.add(array.get(mid));
		
		sortY(midStrip);
		System.out.println("hallo");
		for(int i = 0; i < midStrip.size(); i++){	
			System.out.println(midStrip.get(i).getY());
		}
		//float minMid = 0; //divCon(midStrip);
		int i = 0;
		while (i < midStrip.size()){
			j = i+1;
			while(j < midStrip.size() && Math.abs(midStrip.get(i).getY()- midStrip.get(j).getY()) < min){
				if (distance(midStrip.get(i), midStrip.get(j)) < min){
					min = distance(midStrip.get(i), midStrip.get(j));
				}
				j++;
			}
			i++;
		}
		//if(minMid < min){ //if the minimum of the midstrip is smaller than the minimum of left and right
			//System.out.println("Smallest Distance: " + minMid);
			//return minMid; // minMid is returned because it is the ultimate minimal distance
		//}
		//System.out.println("Smallest Distance: " + min);
		//System.out.println(" Starting Point: " + array.get(positionStart).getX() + " " + array.get(positionStart).getY() );
		//System.out.println(" Destination Point: " + array.get(positionEnd).getX() + " " + array.get(positionEnd).getY());
		
		// if that is not the case min is the ultimate minimum and min is returned
		return min; 
	}
	
	private static float naiveAlg(ArrayList<Point> array){
		float min = Float.MAX_VALUE;
		//float min2 = Integer.MAX_VALUE; 
		int positionStart = 0;
		int positionEnd = 0;
		int xStart = 0;
		int yStart = 0;
		int xEnd = 0;
		int yEnd = 0;
	
		for (int i = 0; i < array.size(); i++){ //iterates through array
			xStart = array.get(i).getX(); 		//safes x and y value of start variable
			yStart = array.get(i).getY();
			//System.out.println(xStart + " hop " + yStart);
			
			for(int j = i+1; j < array.size(); j++){
				xEnd = array.get(j).getX();		//safes x and y value in end variable
				yEnd = array.get(j).getY();
				//System.out.println(xEnd + " hip " + yEnd);
				float distance = (float)Math.abs((Math.sqrt(((xEnd-xStart)*(xEnd-xStart)) + ((yEnd-yStart)*(yEnd-yStart)))));
				// calculates distance between start and end
				
				if (distance < min){ // if the distance is smaller than the minimal distance
					min = distance;  // the minimal distance is updated
					positionStart = i; //the start coordinate is at position i
					positionEnd = j;   // the end coordinate is at position j
				}
				
			}
		}
		
		if(array.size() > 0){
			//System.out.println("Smallest Distance: " + min);
			//System.out.println(" Starting Point: " + array.get(positionStart).getX() + " " + array.get(positionStart).getY() );
			//System.out.println(" Destination Point: " + array.get(positionEnd).getX() + " " + array.get(positionEnd).getY());
		}
		return min;
	}
	
	private static void sortX(ArrayList<Point> array){ //sorts array by x values
		int i;  
		Point p = new Point(); 
		int j = 0; 
		
		for (i = 1; i < array.size(); i++){ // starts at second point and iterates through array
			p = array.get(i); //saves element that need to be sorted next in p
			j = i-1;  //j starts one element before i -> j is already sorted
			
			while(j >= 0 && array.get(j).getX() > p.getX()){ //iterates through already sorted part of the array and compares x values
				//stops at beginning of the array or until there are no smaller elements before the element at j
				array.set(j+1, array.get(j)); //moves element at position j one place to the right(->one index up)
				j = j-1; //j moves one to the left
			}
			array.set(j+1, p); //inserts p into the array
		}
	}
	
	private static void sortY(ArrayList<Point> array){ //sorts array by y values
		int i;  
		Point p = new Point(); 
		int j = 0; 
		
		for (i = 1; i < array.size(); i++){ // starts at second point and iterates through array
			p = array.get(i); //saves element that need to be sorted next in p
			j = i-1;  //j starts one element before i -> j is already sorted
			
			while(j >= 0 && array.get(j).getY() > p.getY()){ //iterates through already sorted part of the array and compares x values
				//stops at beginning of the array or until there are no smaller elements before the element at j
				array.set(j+1, array.get(j)); //moves element at position j one place to the right(->one index up)
				j = j-1; //j moves one to the left
			}
			array.set(j+1, p); //inserts p into the array
		}
	}
	
	private static void printArr(ArrayList<Point> array){
		for (int i = 0; i < array.size(); i++){
			System.out.println("(" + array.get(i).getX() + ", " + array.get(i).getY() + ") ");
		}
	}
	
	public static void main (String [] args){
		ArrayList<Point> arr = new ArrayList<Point>();
		arr = randArr(8);
		arr.add(new Point(1, 2));
		arr.add(new Point(2, 2));
		printArr(arr);
		//naiveAlg(arr); 		//works!
		System.out.println(divCon(arr));
		//sortY(arr);  		//works!
		//printArr(arr);	//works!
		
		
		
	}

}
