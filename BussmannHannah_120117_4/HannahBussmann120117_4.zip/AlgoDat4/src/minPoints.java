import java.util.*;
public class minPoints {
	Point p1 = new Point();
	Point p2 = new Point();
	float distance;
}
