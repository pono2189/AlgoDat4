import java.util.*;
import java.lang.Math; 
public class DivideConquer {
	private static ArrayList<Point> randArr(int size){ //parameter size is the length of the array
												// -> the number of random points you want to have 
		Random rand = new Random();
		ArrayList<Point> array = new ArrayList<Point>();
		if(size < 0){
			System.out.println("Error - Invalid input");
			return array;
		}
		for (int i = 0; i < size; i++){ //creates an array list the size of the parameter size
			Point p = new Point(rand.nextInt()%100,rand.nextInt()%100); //creates new point with random x&y values
			// to make it easier to check, I wanted only numbers < 100, so I used random numbers modulo 100
			array.add(p); //add point p to the array
		}
		return array;
	}
	
	private static float distance(Point p1, Point p2) //return the distance between two points
	{ 
	    return (float)Math.abs((Math.sqrt(((p1.getX()-p2.getX())*(p1.getX()-p2.getX())) + ((p1.getY()-p2.getY())*(p1.getY()-p2.getY())))));
	} 
	
	private static minPoints divCon(ArrayList<Point> array){
		minPoints p = new minPoints(); // p consists of the two points with the minimal distance and the minimal distance as integer
		minPoints minR = new minPoints();
		minPoints minL = new minPoints();
		minL.distance = Float.MAX_VALUE;
		minR.distance = Float.MAX_VALUE;
		p.distance = Float.MAX_VALUE;
		ArrayList<Point> left = new ArrayList<Point>(); 
		ArrayList<Point> right = new ArrayList<Point>();
		//float minR = Float.MAX_VALUE; 
		//float minL = Float.MAX_VALUE;
		float min = Float.MAX_VALUE;
		sortX(array);
		
		if (array.size() <= 3){
			return naiveAlg(array); //if there are only 3 elements or less in the array 
			//because then we compare the distances of the elements at 0&1, 0&2, 1&2
		}
		
		for (int i = 0; i <= array.size()/2; i++){ //safes the first half of array in left
			left.add(array.get(i));
		}
		
		for (int i = (array.size()/2)+1; i < array.size(); i++){ //safes the second half of array in right
			right.add(array.get(i));
		}
				
		minL = divCon(left); //gets minimal distance on the left
		minR = divCon(right); //gets minimal distance on the right
		
		if (minL.distance <= minR.distance){  // compares the distances of minL and minR to get the ultimate minimum
			p = minL;
		}
		
		else{
			p = minR;
		}
		
		ArrayList<Point> midStrip = new ArrayList<Point>();
		int mid = array.size()/2; //start at the middle
		int j = (array.size()/2) - 1; //starts one before the middle
		
		while ((j >= 0) && (Math.abs(array.get(mid).getX() - array.get(j).getX()) <= min )){ //adds the points within range of min from i
			midStrip.add(array.get(j));
			j--;
		}
		
		j = (array.size()/2) + 1; //starts one after the middle
		
		while ((array.size() > j)&&(Math.abs(array.get(mid).getX()- array.get(j).getX()) <= min) ){
			midStrip.add(array.get(j)); //adds all of the points from the middle strip that are within the min distance to i
			j++;
		}
		midStrip.add(array.get(mid)); //adds the middle point to midStrip
		
		sortY(midStrip); //sorts the midStrip points along the y-axis


		int i = 0;
		while (i < midStrip.size()){ //iterates through every point in midStrip
			j = i+1;
			//second iterator starts after the first to compare all of the other points to the first point
			while(j < midStrip.size() && Math.abs(midStrip.get(i).getY()- midStrip.get(j).getY()) < min){
				//as long as the distance between the y coordinates is smaller than min
				if (distance(midStrip.get(i), midStrip.get(j)) < p.distance){
					// if there is a smaller distance than the smallest distance so far
					//then the smallest distance is updated
					p.distance = distance(midStrip.get(i), midStrip.get(j));
					p.p1 = midStrip.get(i);
					p.p2 = midStrip.get(j);
				}
				j++;
			}
			i++;
		}
		
		return p; 
	}
	
	private static minPoints naiveAlg(ArrayList<Point> array){
		minPoints p = new minPoints();
		float min = Float.MAX_VALUE;
		//float min2 = Integer.MAX_VALUE; 
		int positionStart = 0;
		int positionEnd = 0;
		int xStart = 0;
		int yStart = 0;
		int xEnd = 0;
		int yEnd = 0;
	
		for (int i = 0; i < array.size(); i++){ //iterates through array
			xStart = array.get(i).getX(); 		//safes x and y value of start variable
			yStart = array.get(i).getY();
			//System.out.println(xStart + " hop " + yStart);
			
			for(int j = i+1; j < array.size(); j++){
				xEnd = array.get(j).getX();		//safes x and y value in end variable
				yEnd = array.get(j).getY();
				//System.out.println(xEnd + " hip " + yEnd);
				float distance = (float)Math.abs((Math.sqrt(((xEnd-xStart)*(xEnd-xStart)) + ((yEnd-yStart)*(yEnd-yStart)))));
				// calculates distance between start and end
				
				if (distance < min){ // if the distance is smaller than the minimal distance
					min = distance;  // the minimal distance is updated
					positionStart = i; //the start coordinate is at position i
					positionEnd = j;   // the end coordinate is at position j
				}
				
			}
		}
		
		p.distance = min;
		p.p1 = array.get(positionStart);
		p.p2 = array.get(positionEnd);
		
		//if(array.size() > 0){
			//System.out.println("Smallest Distance: " + min);
			//System.out.println(" Starting Point: " + array.get(positionStart).getX() + " " + array.get(positionStart).getY() );
			//System.out.println(" Destination Point: " + array.get(positionEnd).getX() + " " + array.get(positionEnd).getY());
		//}
		return p;
	}
	
	private static void sortX(ArrayList<Point> array){ //sorts array by x values
		int i;  
		Point p = new Point(); 
		int j = 0; 
		
		for (i = 1; i < array.size(); i++){ // starts at second point and iterates through array
			p = array.get(i); //saves element that need to be sorted next in p
			j = i-1;  //j starts one element before i -> j is already sorted
			
			while(j >= 0 && array.get(j).getX() > p.getX()){ //iterates through already sorted part of the array and compares x values
				//stops at beginning of the array or until there are no smaller elements before the element at j
				array.set(j+1, array.get(j)); //moves element at position j one place to the right(->one index up)
				j = j-1; //j moves one to the left
			}
			array.set(j+1, p); //inserts p into the array
		}
	}
	
	private static void sortY(ArrayList<Point> array){ //sorts array by y values
		int i;  
		Point p = new Point(); 
		int j = 0; 
		
		for (i = 1; i < array.size(); i++){ // starts at second point and iterates through array
			p = array.get(i); //saves element that need to be sorted next in p
			j = i-1;  //j starts one element before i -> j is already sorted
			
			while(j >= 0 && array.get(j).getY() > p.getY()){ //iterates through already sorted part of the array and compares x values
				//stops at beginning of the array or until there are no smaller elements before the element at j
				array.set(j+1, array.get(j)); //moves element at position j one place to the right(->one index up)
				j = j-1; //j moves one to the left
			}
			array.set(j+1, p); //inserts p into the array
		}
	}
	
	private static void printArr(ArrayList<Point> array){
		for (int i = 0; i < array.size(); i++){
			System.out.println("(" + array.get(i).getX() + ", " + array.get(i).getY() + ") ");
		}
	}
	
	private static void printSolution(ArrayList<Point> array){ //puts the array in both algorithms and
		//and prints the outcome to see if the solutions are identical
		if(array.size()<=1){
			System.out.println("Error- there are too few points in the Array.");
			return;
		}
		
		System.out.println("Divide and Conquer: ");
		System.out.println("x1: " + divCon(array).p1.getX()+ " y1: "+ divCon(array).p1.getY());	
		System.out.println("x2: " + divCon(array).p2.getX() + " y2: " + divCon(array).p2.getY());
		System.out.println("distance: " + divCon(array).distance);
		
		System.out.println("");
		System.out.println("Naive Algorithm: ");
		System.out.println("x1: " + naiveAlg(array).p1.getX()+ " y1: "+ naiveAlg(array).p1.getY());	
		System.out.println("x2: " + naiveAlg(array).p2.getX() + " y2: " + naiveAlg(array).p2.getY());
		System.out.println("distance: " + naiveAlg(array).distance);
		
		
	}
	
	public static void main (String [] args){
		System.out.println("Array 1 ");
		ArrayList<Point> arr1 = new ArrayList<Point>();
		System.out.println("sorted by y values: ");	
		arr1 = randArr(8);
		sortY(arr1);
		printArr(arr1);
		System.out.println("sorted by x values: ");
		sortX(arr1);
		printArr(arr1);
		//printArr(arr);
		printSolution(arr1);
		
		System.out.println("\nArray 2 ");
		ArrayList<Point> arr2 = new ArrayList<Point>();
		arr2 = randArr(0);
		printSolution(arr2);
		
		System.out.println("\nArray 3 ");
		ArrayList<Point> arr3 = new ArrayList<Point>();
		arr3 = randArr(-10);
		printSolution(arr3);
		
		System.out.println("\nArray 4 ");
		ArrayList<Point> arr4 = new ArrayList<Point>();
		arr4 = randArr(10);
		printSolution(arr4);
		
		
		
	}

}
